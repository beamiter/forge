//! Markdown text layer for notebook surfaces: fence splitting and rendering
//! to Pango markup. Pure string processing — the notebook UI and cell
//! execution stay in each app.

/// Shared upper bound before parsing duplicates any notebook source text.
pub const MAX_NOTEBOOK_SOURCE_BYTES: usize = 4 * 1024 * 1024;
/// A fence storm cannot make frontends allocate an unbounded widget list.
pub const MAX_NOTEBOOK_SEGMENTS: usize = 1_024;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NotebookParseError {
    SourceTooLarge,
    TooManySegments,
}

impl std::fmt::Display for NotebookParseError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::SourceTooLarge => write!(
                formatter,
                "notebook exceeds the {MAX_NOTEBOOK_SOURCE_BYTES}-byte parser limit"
            ),
            Self::TooManySegments => write!(
                formatter,
                "notebook exceeds the {MAX_NOTEBOOK_SEGMENTS}-segment parser limit"
            ),
        }
    }
}

impl std::error::Error for NotebookParseError {}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Segment {
    /// Plain markdown text (may contain inline formatting we render with
    /// pango markup).
    Text(String),
    /// A fenced code block. `lang` is the optional info string after the
    /// opening fence (e.g. "bash", "rust", "" for an unlabeled fence).
    Code { lang: String, src: String },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Fence {
    marker: u8,
    length: usize,
}

fn leading_indent(line: &str) -> Option<&str> {
    let stripped = line.trim_start_matches(' ');
    (line.len() - stripped.len() <= 3).then_some(stripped)
}

fn opening_fence(line: &str) -> Option<(Fence, &str)> {
    let stripped = leading_indent(line)?;
    let marker = *stripped.as_bytes().first()?;
    if marker != b'`' && marker != b'~' {
        return None;
    }
    let length = stripped
        .as_bytes()
        .iter()
        .take_while(|byte| **byte == marker)
        .count();
    if length < 3 {
        return None;
    }
    let info = stripped[length..].trim();
    if marker == b'`' && info.as_bytes().contains(&b'`') {
        return None;
    }
    Some((Fence { marker, length }, info))
}

fn is_closing_fence(line: &str, opening: Fence) -> bool {
    let Some(stripped) = leading_indent(line) else {
        return false;
    };
    let marker_count = stripped
        .as_bytes()
        .iter()
        .take_while(|byte| **byte == opening.marker)
        .count();
    marker_count >= opening.length && stripped[marker_count..].trim().is_empty()
}

fn push_text(segments: &mut Vec<Segment>, text: String) {
    if text.is_empty() {
        return;
    }
    if let Some(Segment::Text(previous)) = segments.last_mut() {
        previous.push_str(&text);
    } else {
        segments.push(Segment::Text(text));
    }
}

/// Split a markdown source into text + code segments. We recognise backtick
/// and tilde fences of length three or greater, including CommonMark's three
/// allowed leading spaces. Unterminated fences remain visible as text.
pub fn parse_segments(input: &str) -> Vec<Segment> {
    match try_parse_segments(input) {
        Ok(segments) => segments,
        Err(error) => vec![Segment::Text(format!("[Notebook omitted: {error}]\n"))],
    }
}

/// Checked form of [`parse_segments`]. Frontends that can surface an open
/// error should prefer this over the compatibility wrapper.
pub fn try_parse_segments(input: &str) -> Result<Vec<Segment>, NotebookParseError> {
    if input.len() > MAX_NOTEBOOK_SOURCE_BYTES {
        return Err(NotebookParseError::SourceTooLarge);
    }
    let mut segments = Vec::new();
    let mut text = String::new();
    let mut lines = input.lines();

    while let Some(line) = lines.next() {
        let Some((fence, info)) = opening_fence(line) else {
            text.push_str(line);
            text.push('\n');
            continue;
        };

        push_text(&mut segments, std::mem::take(&mut text));
        if segments.len() >= MAX_NOTEBOOK_SEGMENTS {
            return Err(NotebookParseError::TooManySegments);
        }
        let mut source = String::new();
        let mut closed = false;
        for inner in lines.by_ref() {
            if is_closing_fence(inner, fence) {
                closed = true;
                break;
            }
            source.push_str(inner);
            source.push('\n');
        }

        if closed {
            if source.ends_with('\n') {
                source.pop();
            }
            segments.push(Segment::Code {
                lang: info.to_owned(),
                src: source,
            });
            if segments.len() > MAX_NOTEBOOK_SEGMENTS {
                return Err(NotebookParseError::TooManySegments);
            }
        } else {
            text.push_str(line);
            text.push('\n');
            text.push_str(&source);
        }
    }

    push_text(&mut segments, text);
    if segments.len() > MAX_NOTEBOOK_SEGMENTS {
        return Err(NotebookParseError::TooManySegments);
    }
    Ok(segments)
}

/// Render the markdown body of a `Text` segment to a Pango-markup string.
/// Just enough to look like markdown without pulling in a full crate:
/// `#/##/###` → bolded sized text, `**x**` → bold, `*x*` → italic,
/// `` `x` `` → monospace span. All other text passes through after XML
/// escaping.
pub fn render_text_to_pango(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    for raw_line in text.lines() {
        let line = raw_line.trim_end();
        if line.is_empty() {
            out.push('\n');
            continue;
        }
        // Heading detection — only if the # appears at line start.
        let (open, body, close) = if let Some(rest) = line.strip_prefix("### ") {
            ("<span weight=\"bold\" size=\"large\">", rest, "</span>")
        } else if let Some(rest) = line.strip_prefix("## ") {
            ("<span weight=\"bold\" size=\"x-large\">", rest, "</span>")
        } else if let Some(rest) = line.strip_prefix("# ") {
            ("<span weight=\"bold\" size=\"xx-large\">", rest, "</span>")
        } else {
            ("", line, "")
        };
        out.push_str(open);
        out.push_str(&render_inline(body));
        out.push_str(close);
        out.push('\n');
    }
    out
}

/// Apply only flat inline spans. Generated tags never re-enter the marker
/// parser, and a code span's contents always stay literal. Nested or
/// overlapping formatting remains visible as text rather than emitting
/// crossing XML tags that make Pango reject the entire label.
fn render_inline(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut rest = s;
    while let Some(start) = rest.find(['`', '*']) {
        out.push_str(&escape_pango(&rest[..start]));
        rest = &rest[start..];
        let byte = rest.as_bytes()[0];
        let run = rest
            .bytes()
            .take_while(|candidate| *candidate == byte)
            .count();
        if (byte == b'`' && run != 1) || (byte == b'*' && run > 2) {
            out.push_str(&rest[..run]);
            rest = &rest[run..];
            continue;
        }
        let marker = &rest[..run];
        let after = &rest[run..];
        let Some(end) = closing_inline_marker(after, marker) else {
            out.push_str(&escape_pango(rest));
            return out;
        };
        let body = &after[..end];
        let consumed = run + end + run;
        if byte != b'`' && body.contains(['`', '*']) {
            out.push_str(&escape_pango(&rest[..consumed]));
        } else {
            let (open, close) = match marker {
                "`" => ("<tt>", "</tt>"),
                "**" => ("<b>", "</b>"),
                _ => ("<i>", "</i>"),
            };
            out.push_str(open);
            out.push_str(&escape_pango(body));
            out.push_str(close);
        }
        rest = &rest[consumed..];
    }
    out.push_str(&escape_pango(rest));
    out
}

/// A delimiter must be a whole run: one `*` cannot close in the middle of
/// `**`, and unsupported longer runs remain literal.
fn closing_inline_marker(s: &str, marker: &str) -> Option<usize> {
    let byte = marker.as_bytes()[0];
    let mut offset = 0;
    while let Some(relative) = s[offset..].find(marker) {
        let start = offset + relative;
        let end = start + marker.len();
        if (start == 0 || s.as_bytes()[start - 1] != byte)
            && s.as_bytes().get(end).is_none_or(|next| *next != byte)
        {
            return Some(start);
        }
        offset = end;
    }
    None
}

fn escape_pango(s: &str) -> String {
    let mut escaped = String::with_capacity(s.len());
    for ch in s.chars() {
        match ch {
            '&' => escaped.push_str("&amp;"),
            '<' => escaped.push_str("&lt;"),
            '>' => escaped.push_str("&gt;"),
            '\t' => escaped.push('\t'),
            ch if ch.is_control() || crate::review_input::is_visual_spoofing_character(ch) => {
                escaped.push('\u{fffd}');
            }
            ch => escaped.push(ch),
        }
    }
    escaped
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn splits_text_and_code_fences() {
        let md = "Intro line\n```bash\necho hi\n```\nMiddle\n```\nls\n```\ntail";
        let segs = parse_segments(md);
        assert_eq!(segs.len(), 5);
        assert!(matches!(segs[0], Segment::Text(_)));
        assert!(matches!(segs[1], Segment::Code { .. }));
        assert!(matches!(segs[2], Segment::Text(_)));
        assert!(matches!(segs[3], Segment::Code { .. }));
        assert!(matches!(segs[4], Segment::Text(_)));
        if let Segment::Code { lang, src } = &segs[1] {
            assert_eq!(lang, "bash");
            assert_eq!(src, "echo hi");
        }
        if let Segment::Code { lang, src } = &segs[3] {
            assert_eq!(lang, "");
            assert_eq!(src, "ls");
        }
    }

    #[test]
    fn tilde_fences_recognised() {
        let md = "~~~sh\nwhoami\n~~~\n";
        let segs = parse_segments(md);
        assert_eq!(segs.len(), 1);
        assert!(matches!(segs[0], Segment::Code { .. }));
    }

    #[test]
    fn longer_fence_does_not_close_on_a_shorter_marker() {
        let md = "````bash\necho ``` literal\n```\n````\n";
        assert_eq!(
            parse_segments(md),
            vec![Segment::Code {
                lang: "bash".to_owned(),
                src: "echo ``` literal\n```".to_owned(),
            }]
        );
    }

    #[test]
    fn unterminated_fence_falls_back_to_text() {
        let md = "before\n```bash\necho oops\nno closing fence here\n";
        let segs = parse_segments(md);
        // Should be one big text segment, not a code segment.
        assert!(segs.iter().all(|s| matches!(s, Segment::Text(_))));
    }

    #[test]
    fn empty_input_yields_no_segments() {
        assert!(parse_segments("").is_empty());
    }

    #[test]
    fn parser_rejects_oversize_source_before_copying_it() {
        let oversized = "x".repeat(MAX_NOTEBOOK_SOURCE_BYTES + 1);
        assert_eq!(
            try_parse_segments(&oversized),
            Err(NotebookParseError::SourceTooLarge)
        );
        let fallback = parse_segments(&oversized);
        assert_eq!(fallback.len(), 1);
        assert!(matches!(&fallback[0], Segment::Text(text) if text.contains("omitted")));
    }

    #[test]
    fn parser_rejects_a_fence_storm_instead_of_returning_partial_code() {
        let source = "```sh\ntrue\n```\n".repeat(MAX_NOTEBOOK_SEGMENTS + 1);
        assert_eq!(
            try_parse_segments(&source),
            Err(NotebookParseError::TooManySegments)
        );
        assert!(parse_segments(&source)
            .iter()
            .all(|segment| matches!(segment, Segment::Text(_))));
    }

    #[test]
    fn escape_pango_handles_ampersand_and_angles() {
        assert_eq!(escape_pango("a & b < c > d"), "a &amp; b &lt; c &gt; d");
    }

    #[test]
    fn pango_text_makes_controls_and_visual_spoofing_visible() {
        assert_eq!(
            escape_pango("safe\u{00a0}\u{2003}\u{202e}\u{200b}\u{00ad}\u{fe0f}\u{e0020}\0\ttext"),
            "safe��������\ttext"
        );
    }

    #[test]
    fn inline_code_keeps_formatting_markers_literal() {
        assert_eq!(
            render_inline("`**bold** and *italic* <&>`"),
            "<tt>**bold** and *italic* &lt;&amp;&gt;</tt>"
        );
        assert_eq!(
            render_inline("中文 `<&🙂>` **粗体** *é*"),
            "中文 <tt>&lt;&amp;🙂&gt;</tt> <b>粗体</b> <i>é</i>"
        );
    }

    #[test]
    fn nested_and_overlapping_markers_stay_literal() {
        for input in [
            "*foo **bar* baz**",
            "**a *b** c*",
            "*a `b* c`",
            "***text***",
        ] {
            assert_eq!(render_inline(input), input);
        }
        assert_eq!(
            render_inline("**one** *two* `three`"),
            "<b>one</b> <i>two</i> <tt>three</tt>"
        );
    }

    #[test]
    fn marker_combinations_never_cross_generated_tags() {
        fn check(markup: &str) {
            let mut tags = Vec::new();
            let mut rest = markup;
            while let Some(start) = rest.find('<') {
                rest = &rest[start..];
                let end = rest.find('>').unwrap();
                let tag = &rest[1..end];
                if let Some(close) = tag.strip_prefix('/') {
                    assert_eq!(tags.pop(), Some(close), "{markup}");
                } else {
                    assert!(matches!(tag, "b" | "i" | "tt"), "{markup}");
                    tags.push(tag);
                }
                rest = &rest[end + 1..];
            }
            assert!(tags.is_empty(), "{markup}");
        }
        for value in 0..5usize.pow(6) {
            let mut n = value;
            let mut input = String::new();
            for _ in 0..6 {
                input.push(['*', '`', 'a', '<', '&'][n % 5]);
                n /= 5;
            }
            check(&render_inline(&input));
        }
    }

    #[test]
    fn render_inline_bolds_and_italicises() {
        let r = render_inline("look at **this** and *that*");
        assert!(r.contains("<b>this</b>"), "got {r}");
        assert!(r.contains("<i>that</i>"), "got {r}");
    }

    #[test]
    fn render_inline_wraps_backtick_code() {
        let r = render_inline("run `ls -la` please");
        assert!(r.contains("<tt>ls -la</tt>"), "got {r}");
    }

    #[test]
    fn render_inline_leaves_unmatched_markers_alone() {
        // A single unmatched ** must not produce dangling tags or panic.
        let r = render_inline("oops **forgot to close");
        assert!(!r.contains("<b>"), "got {r}");
    }

    #[test]
    fn render_text_to_pango_handles_headings() {
        let out = render_text_to_pango("# Title\n\nbody");
        assert!(out.contains("Title</span>"), "got {out}");
    }

    #[test]
    fn fence_with_leading_spaces_recognised() {
        let md = "  ```bash\necho ok\n  ```\n";
        let segs = parse_segments(md);
        assert!(
            matches!(segs.first(), Some(Segment::Code { .. })),
            "got {segs:?}"
        );
    }
}
